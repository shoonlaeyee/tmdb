import { useEffect, useState } from "react";
import { fetchMovieList } from "../api/Api";
import { GenreDropdown } from "../components/GenreDropdown";
import { MovieList, MovieListLoading } from "../components/MovieList";

export const Home = () => {
  const [loading, setLoading] = useState(true);
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    fetchMovieList().then((data) => {
      const { page, results, total_pages } = data;
      setMovies(results);
      setLoading(false);
    });
  }, []);

  return (
    <div className="">
      <div className="d-flex gap-3 px-3 align-items-center fw-light">
        <div className="fs-4">Movies</div>
        <GenreDropdown />
      </div>
      <MovieList movies={movies} />
      {loading && <MovieListLoading size={9} />}
    </div>
  );
};
