import { useEffect, useState } from "react";
import {
  fetchMovieCredits,
  fetchMovieDetail,
  fetchMovieKeywords,
  fetchSimilarMovies,
} from "../api/Api";
import { useParams } from "react-router-dom";
import { MovieList, MovieListLoading } from "../components/MovieList";
import { ImgPosterBaseUrl, ImgBackdropBaseUrl } from "../api/Api";
import dayjs from "dayjs";
import { CircularProgressbar, buildStyles } from "react-circular-progressbar";

export const MovieDetail = () => {
  const [loading, setLoading] = useState(true);
  const [movie, setMovie] = useState(null);
  const [casts, setCasts] = useState([]);
  const [crews, setCrews] = useState([]);
  const [keywords, setKeywords] = useState([]);
  const [similarMovies, setSimilarMovies] = useState([]);

  const { movieId } = useParams();

  useEffect(() => {
    fetchMovieDetail({ movieId }).then((data) => {
      setMovie(data);
      setLoading(false);
    });
    fetchMovieCredits({ movieId }).then(({ crew, cast }) => {
      setCasts(cast);
      setCrews(crew);
    });
    fetchMovieKeywords({ movieId }).then(({ keywords }) => {
      setKeywords(keywords);
    });
    fetchSimilarMovies({ movieId }).then(({ results }) => {
      setSimilarMovies(results.filter((v, i) => i < 10));
    });
  }, [movieId]);

  if (loading)
    return (
      <div className="p-3">
        <MovieListLoading size={5} />
      </div>
    );

  const productionCompany = movie.production_companies.find((c, i) => i === 0);
  const runtimeHourMinute = [movie.runtime / 60, movie.runtime % 60];
  const userScorePercentage = Math.floor(movie.vote_average * 10);

  const characterCrew = crews.find((v) => v.job === "Characters");
  const directorCrew = crews.find((v) => v.job === "Director");
  const writerCrews = crews.filter((v) => v.job === "Writer");
  const crewsToShow = [characterCrew, directorCrew, ...writerCrews];

  const renderCasts = casts.map((c) => (
    <div
      key={c.id}
      className="rounded-2 shadow overflow-hidden bg-dark"
      style={{ minWidth: 160, height: "auto" }}
      role="button"
    >
      {c.profile_path && (
        <img
          src={ImgPosterBaseUrl + c.profile_path}
          alt={c.name}
          className="w-100"
        />
      )}
      {!c.profile_path && (
        <div
          className="d-flex justify-content-center align-items-center bg-secondary"
          style={{ height: 240 }}
        >
          <i
            class="bi bi-person-fill"
            style={{ fontSize: 62, color: "#a0a0a0" }}
          ></i>
        </div>
      )}
      <div className="p-2">
        <div className="fw-bold">{c.name}</div>
        <div className="fw-light">{c.character}</div>
      </div>
    </div>
  ));

  const renderKeywords = keywords.map((k) => (
    <div key={k.id} className="bg-secondary text-dark rounded-1 px-1">
      <small>{k.name}</small>
    </div>
  ));

  return (
    <div className="">
      <div className="position-relative">
        <img
          src={ImgBackdropBaseUrl + movie.backdrop_path}
          alt={movie.title}
          className="w-100"
        />
        <div className="position-absolute left-0 right-0 top-0 bottom-0 p-3 shadow-lg detail-backdrop">
          <div className="d-flex">
            <div className="col-3">
              <img
                src={ImgPosterBaseUrl + movie.poster_path}
                alt={movie.title}
                className="w-100 rounded-2"
              />
            </div>
            <div className="col-* py-4 px-5">
              <div className="d-flex gap-2 fw-bold align-items-center lh-1">
                <div className="fs-2">{movie.title}</div>
                <div className="fw-light fs-3">
                  ({dayjs(movie.release_date).format("YYYY")})
                </div>
              </div>
              <div className="d-flex gap-2 align-items-center fw-light fs-6">
                <div className="d-flex gap-1">
                  {movie.release_date}
                  {!!productionCompany && (
                    <span>({productionCompany.origin_country})</span>
                  )}
                </div>
                <div
                  className="rounded-circle bg-light"
                  style={{ width: 6, height: 6 }}
                ></div>
                <div className="d-flex gap-2 py-2">
                  {movie.genres.map((g) => g.name).join(", ")}
                </div>
                <div
                  className="rounded-circle bg-light"
                  style={{ width: 6, height: 6 }}
                ></div>
                <div className="">
                  <span>
                    {Math.floor(runtimeHourMinute[0])}h{" "}
                    {Math.floor(runtimeHourMinute[1])}m
                  </span>
                </div>
              </div>
              <div className="d-flex gap-2 align-items-center pb-2">
                <div
                  className="rounded-circle"
                  style={{
                    width: 60,
                    height: 60,
                    background: "#001100",
                    padding: 2,
                  }}
                >
                  <CircularProgressbar
                    value={userScorePercentage}
                    strokeWidth={10}
                    text={`${userScorePercentage}%`}
                    styles={buildStyles({
                      backgroundColor: "red",
                      trailColor: "#004400",
                      pathColor: "green",
                      textColor: "white",
                      textSize: 22,
                    })}
                  />
                </div>
                <div className="fw-bold lh-sm">
                  <div>User</div>
                  <div>Score</div>
                </div>
              </div>
              <div className="fw-light text-white-50">
                <i>{movie.tagline}</i>
              </div>
              <div className="fw-bold fs-5 pt-2">Overview</div>
              <div className="fw-light">{movie.overview}</div>
              <div className="crews-grid pt-3">
                {crewsToShow.map(
                  (c) =>
                    !!c && (
                      <div key={c.id} className="" role="button">
                        <div className="fw-bold">{c.name}</div>
                        <div className="text-white-50 fw-light">{c.job}</div>
                      </div>
                    )
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="row p-0">
        <div className="col-9">
          <div className="p-3 pb-0 fs-4">Casts</div>
          <div className="d-flex overflow-x-auto gap-3 p-3">{renderCasts}</div>
          <div className="p-3 pb-0 fs-4">Similar Movies</div>
          <MovieList movies={similarMovies} />
        </div>
        <div
          className="col-3 d-flex flex-column gap-3"
          style={{ background: "#24242455" }}
        >
          <div className="py-0 lh-sm">
            <a
              href={movie.homepage}
              alt={movie.homepage}
              title={movie.homepage}
            >
              <i class="bi bi-link fs-1"></i>
            </a>
          </div>
          <div className="d-flex flex-column lh-sm">
            <div className="fw-bold">Status</div>
            <div className="fw-light">{movie.status}</div>
          </div>
          <div className="d-flex flex-column lh-sm">
            <div className="fw-bold">Original Language</div>
            <div className="fw-light">
              {movie.spoken_languages.find(
                (l) => l.iso_639_1 === movie.original_language
              )?.name || movie.original_language}
            </div>
          </div>
          <div className="d-flex flex-column lh-sm">
            <div className="fw-bold">Budget</div>
            <div className="fw-light">
              ${movie.budget.toLocaleString() || 0}
            </div>
          </div>
          <div className="d-flex flex-column lh-sm">
            <div className="fw-bold">Revenue</div>
            <div className="fw-light">
              ${movie.revenue.toLocaleString() || 0}
            </div>
          </div>
          <div className="pb-3">
            <div className="fs-5 fw-bold">Keywords</div>
            <div className="d-flex gap-2 flex-wrap pt-2">{renderKeywords}</div>
          </div>
        </div>
      </div>

      {/* <pre>{JSON.stringify(similarMovies, null, 2)}</pre> */}
    </div>
  );
};
