import { useEffect, useState } from "react";
import { fetchGenres } from "../api/Api";

export const GenreDropdown = () => {
  const [genres, setGenres] = useState([]);

  useEffect(() => {
    fetchGenres().then(({ genres }) => {
      setGenres(genres);
    });
  }, []);

  const renderItems = genres.map((g) => (
    <li key={g.id}>
      <button type="button" className="dropdown-item fw-light">
        <small>{g.name}</small>
      </button>
    </li>
  ));

  return (
    <div className="dropdown">
      <button
        className="btn btn-sm btn-outline-secondary dropdown-toggle py-0"
        type="button"
        data-bs-toggle="dropdown"
        aria-expanded="false"
      >
        Genres
      </button>
      <ul className="dropdown-menu dropdown-menu-dark">{renderItems}</ul>
    </div>
  );
};
