import { useNavigate } from "react-router-dom";

export const Nav = () => {
  const navigate = useNavigate();

  const onClickIcon = () => {
    navigate("/");
  };

  return (
    <div className="py-2 px-3 d-flex justify-content-between align-items-center">
      <div
        className="d-flex align-items-center gap-3"
        role="button"
        onClick={onClickIcon}
      >
        <div className="fs-2 fw-bold logo-text">TMDB</div>
      </div>
      <div className="d-flex align-items-center">
        <div className="input-group bg-dark overflow-hidden">
          <input
            type="text"
            className="form-control bg-transparent text-secondary border-secondary"
            placeholder="Title, genre, or keywords"
            size={20}
          />
          <span className="input-group-text bg-transparent border-secondary">
            <i className="bi bi-search text-secondary"></i>
          </span>
        </div>
      </div>
    </div>
  );
};
